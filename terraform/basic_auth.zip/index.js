exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    const headers = request.headers;
    
    const authUser = 'admin';
    const authPass = 'staging123';
    const authString = 'Basic ' + Buffer.from(authUser + ':' + authPass).toString('base64');
    
    if (typeof headers.authorization == 'undefined' || headers.authorization[0].value != authString) {
        const response = {
            status: '401',
            statusDescription: 'Unauthorized',
            headers: {
                'www-authenticate': [{key: 'WWW-Authenticate', value: 'Basic'}]
            }
        };
        return response;
    }
    
    return request;
};
